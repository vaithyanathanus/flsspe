# Azure API Management — Validate JWT Policy

This folder contains the **JWT validation policy** used in Azure API Management (APIM) to authenticate requests using **Microsoft Entra ID (Azure AD)** tokens.

It ensures that only requests from authorized client - Flowsource can reach APIs.

---

## 📘 Overview

The `validate-jwt` policy checks the following:

- The token is issued by your Microsoft Entra ID tenant.

- The token includes the correct `appid` (Application ID of flowsource AKS cluster) claim.

- The request contains a valid `Authorization: Bearer <token>` header.

If the validation fails, the API Management gateway returns **`401 Unauthorized`**.

---

## 🧩 Policy XML Template

```xml
<validate-jwt header-name="Authorization"

              failed-validation-httpcode="401"

              failed-validation-error-message="Unauthorized">
<!-- Tokens are issued by Entra ID (Azure AD) -->
<openid-config url="https://login.microsoftonline.com/${tenant_id}/v2.0/.well-known/openid-configuration" />
<required-claims>
<!-- Require that the caller is exactly your client app -->
<claim name="appid">
<value>${client_app_id}</value>
</claim>
</required-claims>
</validate-jwt>
```

The above XML snippet should be placed within the `<inbound>` section of your API Management policy:

```xml
<!--
    - Policies are applied in the order they appear.
    - Position <base/> inside a section to inherit policies from the outer scope.
    - Comments within policies are not preserved.
-->
<!-- Add policies as children to the <inbound>, <outbound>, <backend>, and <on-error> elements -->
<policies>
    <!-- Throttle, authorize, validate, cache, or transform the requests -->
    <inbound>
        <base />
    </inbound>
    <!-- Control if and how the requests are forwarded to services  -->
    <backend>
        <base />
    </backend>
    <!-- Customize the responses -->
    <outbound>
        <base />
    </outbound>
    <!-- Handle exceptions and customize error responses  -->
    <on-error>
        <base />
    </on-error>
</policies>
```