resource "random_id" "random_role_id_suffix" {
  byte_length = 2
}
data "google_compute_network" "network" {

  project = var.project_id
  name    = var.network
}

locals {
  base_role_id          = "osLoginProjectGet"
  service_account_email = var.service_account_email == "" ? try(google_service_account.bastion_host[0].email, "") : var.service_account_email
  service_account_roles = var.service_account_email == "" ? toset(compact(concat(
    var.service_account_roles,
    var.service_account_roles_supplemental,
  ))) : []
  temp_role_id = var.random_role_id ? format(
    "%s_%s",
    local.base_role_id,
    random_id.random_role_id_suffix.hex,
  ) : local.base_role_id
}

resource "google_service_account" "bastion_host" {
  count        = var.service_account_email == "" ? 1 : 0
  project      = var.project_id
  account_id   = var.service_account_name
  display_name = "Service Account for Bastion"
}

module "vm_instance_template" {
  source              = "terraform-google-modules/vm/google//modules/instance_template"
  version             = "11.1.0"
  name_prefix         = var.vm_template_name
  project_id          = var.project_id
  machine_type        = var.machine_type
  disk_size_gb        = var.disk_size_gb
  disk_type           = var.disk_type
  disk_labels         = var.disk_labels
  subnetwork          = var.subnet
  subnetwork_project  = var.project_id
  additional_networks = var.additional_networks
  region              = var.region

  service_account = {
    email  = local.service_account_email
    scopes = var.scopes
  }
  enable_shielded_vm   = var.shielded_vm
  source_image         = var.image
  source_image_family  = var.image_family
  source_image_project = var.image_project
  startup_script       = file(var.startup_script)
  preemptible          = var.preemptible
  can_ip_forward       = var.can_ip_forward ? "true" : "false"

  tags   = var.tags
  labels = var.labels

  metadata = merge(
    var.metadata,
    {
      enable-oslogin = "TRUE"
    }
  )
}

resource "google_compute_instance_from_template" "bastion_vm" {
  count = var.create_instance_from_template ? 1 : 0

  name    = var.bastion_host_name
  project = var.project_id
  zone    = var.zone
  labels  = var.labels

  network_interface {
    subnetwork         = var.subnet
    subnetwork_project = var.project_id != "" ? var.project_id : var.project_id
    access_config      = var.external_ip ? var.access_config : []
  }

  source_instance_template = module.vm_instance_template.self_link
}

module "bastion-host_iap-tunneling" {
  source                     = "terraform-google-modules/bastion-host/google//modules/iap-tunneling"
  version                    = "6.0.0"
  project                    = var.project_id
  additional_ports           = var.additional_ports
  fw_name_allow_ssh_from_iap = var.fw_name_allow_ssh_from_iap
  network                    = var.network
  service_accounts           = [local.service_account_email]
  instances = var.create_instance_from_template ? [{
    name = try(google_compute_instance_from_template.bastion_vm[0].name, "")
    zone = var.zone
  }] : []
  members              = var.members
  create_firewall_rule = var.create_firewall_rule
}

resource "google_service_account_iam_binding" "bastion_sa_user" {
  count              = var.service_account_email == "" ? 1 : 0
  service_account_id = google_service_account.bastion_host[0].id
  role               = "roles/iam.serviceAccountUser"
  members            = var.members
}

resource "google_project_iam_member" "bastion_sa_bindings" {
  for_each = local.service_account_roles

  project = var.project_id
  role    = each.key
  member  = "serviceAccount:${local.service_account_email}"
}

# If you are practicing least privilege, to enable instance level OS Login, you
# still need the compute.projects.get permission on the project level. The other
# predefined roles grant additional permissions that aren't needed
resource "google_project_iam_custom_role" "compute_os_login_viewer" {

  count       = var.service_account_email == "" ? 1 : 0
  project     = var.project_id
  role_id     = local.temp_role_id
  title       = "OS Login Project Get Role"
  description = "From Terraform: iap-bastion module custom role for more fine grained scoping of permissions"
  permissions = ["compute.projects.get"]
}

resource "google_project_iam_member" "bastion_oslogin_bindings" {

  count   = var.service_account_email == "" ? 1 : 0
  project = var.project_id
  role    = "projects/${var.project_id}/roles/${google_project_iam_custom_role.compute_os_login_viewer[0].role_id}"
  member  = "serviceAccount:${local.service_account_email}"
}

resource "google_compute_firewall" "allow-bastion-to-gke" {

  name    = var.bastion_firewall_name
  network = var.network
  project = var.project_id

  allow {
    protocol = "tcp"
    ports    = ["443"]
  }

  source_tags = ["bastion"]
  target_tags = ["gke-control-plane"]

  source_ranges = ["0.0.0.0/0"]
}